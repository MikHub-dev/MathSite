// Fichier GÉNÉRÉ par outils/compiler-evaluations.mjs : ne pas le modifier à la main.
// Modifier les sources (evaluations/, notes/, eleves/) puis relancer le script.
window.EVALUATIONS = {
 "2026-2027": {
  "5e": [
   {
    "id": "2026-09-25-priorites-operatoires",
    "total": 10,
    "titre": "Enchaînements d'opérations",
    "chapitre": "Calcul et priorités opératoires",
    "date": "2026-09-25",
    "dureeMinutes": 25,
    "consignes": "<p>Évaluation de démonstration. Pour la dernière question, écris chaque étape du calcul sur une nouvelle ligne.</p>",
    "questions": [
     {
      "id": "q1",
      "type": "numerique",
      "points": 2,
      "enonce": "<p>Calcule : 7 + 3 × 5</p>"
     },
     {
      "id": "q2",
      "type": "numerique",
      "points": 2,
      "enonce": "<p>Calcule : (7 + 3) × 5</p>"
     },
     {
      "id": "q3",
      "type": "qcm",
      "points": 2,
      "enonce": "<p>Quelle expression est égale à 20 ?</p>",
      "choix": [
       "4 + 4 × 4",
       "(4 + 4) × 4",
       "4 × 4 − 4",
       "4 + 4 + 4"
      ]
     },
     {
      "id": "q4",
      "type": "redaction",
      "points": 4,
      "enonce": "<p>Calcule en détaillant les étapes : 18 − 12 ÷ 3 + 2 × (5 − 1)</p>"
     }
    ]
   },
   {
    "id": "2026-09-18-nombres-relatifs",
    "total": 10,
    "titre": "Nombres relatifs : repérer et comparer",
    "chapitre": "Nombres relatifs",
    "date": "2026-09-18",
    "dureeMinutes": 30,
    "consignes": "<p>Évaluation de démonstration. Justifiez vos réponses quand la question le demande.</p>",
    "questions": [
     {
      "id": "q1",
      "type": "qcm",
      "points": 2,
      "enonce": "<p>Quel est le plus petit de ces nombres ?</p>",
      "choix": [
       "−3,5",
       "−3",
       "−4,2",
       "0,5"
      ]
     },
     {
      "id": "q2",
      "type": "numerique",
      "points": 2,
      "enonce": "<p>Quelle est la distance à zéro du nombre −7,8 ?</p>"
     },
     {
      "id": "q3",
      "type": "redaction",
      "points": 3,
      "enonce": "<p>Range ces nombres dans l'ordre croissant : 2 ; −1,5 ; −6 ; 0 ; −1 ; 3,2.</p>"
     },
     {
      "id": "q4",
      "type": "qcm",
      "points": 1,
      "enonce": "<p>Sur une droite graduée, le point A a pour abscisse −2 et le point B a pour abscisse 3. Quelle est la longueur AB ?</p>",
      "choix": [
       "1",
       "5",
       "−5",
       "6"
      ]
     },
     {
      "id": "q5",
      "type": "redaction",
      "points": 2,
      "enonce": "<p>À 6 h du matin, il faisait −4 °C. À midi, il fait 5 °C. De combien de degrés la température a-t-elle augmenté ? Explique.</p>"
     }
    ],
    "corrige": {
     "q1": "<p><strong>−4,2</strong>. Parmi des nombres négatifs, le plus petit est celui qui a la plus grande distance à zéro : 4,2 &gt; 3,5 &gt; 3.</p>",
     "q2": "<p><strong>7,8</strong>. La distance à zéro d'un nombre relatif est le nombre sans son signe.</p>",
     "q3": "<p>−6 &lt; −1,5 &lt; −1 &lt; 0 &lt; 2 &lt; 3,2</p>",
     "q4": "<p><strong>5</strong>. De −2 à 0 il y a 2 unités, puis de 0 à 3 il y a 3 unités : 2 + 3 = 5. Une longueur n'est jamais négative.</p>",
     "q5": "<p><strong>9 °C</strong>. Il faut 4 degrés pour passer de −4 °C à 0 °C, puis 5 degrés pour passer de 0 °C à 5 °C : 4 + 5 = 9.</p>"
    },
    "cloturee": true
   }
  ],
  "seconde": [
   {
    "id": "2026-09-24-ensembles-de-nombres",
    "total": 10,
    "titre": "Ensembles de nombres et intervalles",
    "chapitre": "Nombres et calculs",
    "date": "2026-09-24",
    "dureeMinutes": 45,
    "consignes": "<p>Évaluation de démonstration. Vous pouvez écrire les ensembles avec les lettres N, Z, D, Q et R si les symboles ne sont pas disponibles au clavier.</p>",
    "questions": [
     {
      "id": "q1",
      "type": "qcm",
      "points": 2,
      "enonce": "<p>Quel est le plus petit ensemble auquel appartient le nombre −12/4 ?</p>",
      "choix": [
       "ℕ",
       "ℤ",
       "𝔻",
       "ℚ"
      ]
     },
     {
      "id": "q2",
      "type": "qcm",
      "points": 2,
      "enonce": "<p>Le nombre 1/3 est-il un nombre décimal ?</p>",
      "choix": [
       "Oui",
       "Non"
      ]
     },
     {
      "id": "q3",
      "type": "redaction",
      "points": 3,
      "enonce": "<p>Écris l'ensemble des réels x tels que −2 &lt; x ≤ 5 sous la forme d'un intervalle, puis explique le sens de chaque crochet.</p>"
     },
     {
      "id": "q4",
      "type": "numerique",
      "points": 1,
      "enonce": "<p>Combien de nombres entiers relatifs appartiennent à l'intervalle [−3 ; 2[ ?</p>"
     },
     {
      "id": "q5",
      "type": "redaction",
      "points": 2,
      "enonce": "<p>Détermine l'intersection [−1 ; 4] ∩ ]2 ; 7] puis la réunion [−1 ; 4] ∪ ]2 ; 7].</p>"
     }
    ]
   }
  ]
 }
};
window.EVAL_NOTES = {
 "2026-2027": {
  "5e": {
   "2026-09-18-nombres-relatifs": {
    "publieLe": "2026-09-25",
    "notes": {
     "4c8bc363d19e7f5c5a83d15712ec6bb2a816a9fdfa3984bfb80b0a222a586395": {
      "note": 8.5,
      "commentaire": "Très bon travail. À la question 5, écris les deux étapes du raisonnement."
     },
     "797d44179d4711553b25ca3c8e987a6c2efc588dc04c3213d521122000fbebd0": {
      "note": 6,
      "commentaire": "Revois la comparaison des nombres négatifs (question 1)."
     },
     "b450ed7d5d51a8f3c741acb07d49ea7e48850d81fd5c627b59bbe23e5a17556f": {
      "note": 9.5,
      "commentaire": "Excellent."
     },
     "03164f020062140af0e099e804b46268eb71b2f12d3b88c843e4ba4a23ba28b3": {
      "note": 4.5,
      "commentaire": "Relis la leçon sur la distance à zéro et refais les questions 2 et 4."
     },
     "db2c864543578ba00a1015541214cf647b00ebf7ab21eb9a98ff6bb1e4fad4cf": {
      "note": 7,
      "commentaire": "Bien. Attention au rangement de −1,5 et −1."
     }
    }
   }
  }
 }
};
window.EVAL_ELEVES = {"2026-2027":{"5e":["489c1aecd78964bf6e285c1425430f40b6a14f6cc4ba1f9ffd2bc2f48b203a24"],"seconde":["8f29042f5b26a90537a0cec56715742c14a0e793fd534ed7b5478796565bc56f"]}};
window.EVAL_KPI = {
  "genereLe": "2026-09-27T08:05:18.892Z",
  "annees": {
    "2026-2027": {
      "5e": {
        "total": 2,
        "ouvertes": 1,
        "enAttente": null,
        "fermees": 1,
        "copiesCorrigees": 0,
        "moyenneSur20": null
      },
      "seconde": {
        "total": 1,
        "ouvertes": 1,
        "enAttente": null,
        "fermees": 0,
        "copiesCorrigees": 0,
        "moyenneSur20": null
      }
    }
  }
};
